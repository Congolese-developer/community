---
name: "🙋 Join the Community"
about: Introduce yourself and join Congolese Developers. Welcome! 🇨🇩
title: "[Join]: "
labels: ["new-member"]
assignees: []
---

<!--
Welcome to Congolese Developers! 🇨🇩
Fill in the form below. Fields marked (optional) can be left empty.
Do NOT share private information such as phone numbers, addresses or ID numbers — this issue is public.
-->

## 👤 GitHub username

@

## 📍 Province or city (optional)

<!-- Example: Kinshasa, Haut-Katanga / Lubumbashi, Nord-Kivu / Goma, diaspora (Brussels)... -->

## 💻 Programming languages

<!-- Example: Python, JavaScript, Dart -->

## 🎯 Areas of interest

<!-- Check all that apply. -->

- [ ] Backend
- [ ] Frontend
- [ ] Mobile Development
- [ ] Data & Artificial Intelligence
- [ ] DevOps & Cloud Computing
- [ ] Cybersecurity
- [ ] Embedded Systems
- [ ] Scientific Computing
- [ ] Open Data
- [ ] Documentation & Translation
- [ ] Design
- [ ] Other: <!-- tell us -->

## 📈 Experience level (optional)

- [ ] Beginner / student
- [ ] Junior (0–2 years)
- [ ] Intermediate (2–5 years)
- [ ] Senior (5+ years)

## 💬 A few words about you (optional)

<!-- What are you working on? What would you like to learn or build with the community? -->

## 🏢 Organization membership

- [ ] I would like to be invited to the Congolese Developers GitHub organization.

---

- [ ] I have read and agree to follow the [Code of Conduct](../blob/main/CODE_OF_CONDUCT.md).
