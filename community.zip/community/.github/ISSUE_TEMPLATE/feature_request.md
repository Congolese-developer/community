---
name: "✨ Feature Request"
about: Suggest a new feature for the community hub (a new template, guide, tool or process).
title: "[Feature]: "
labels: ["enhancement", "needs-triage"]
assignees: []
---

<!--
Thank you for your idea! 💡
To improve something that already exists, use the "Improvement Suggestion" template instead.
To propose a whole new open-source project, use the "Project Proposal" template.
-->

## ✨ Feature description

<!-- Describe the feature you would like to see. -->

## 🎯 Problem being solved

<!-- What problem does this feature solve? Who is affected? Example: "Beginners can't find..." -->

## 🌟 Expected benefits

<!-- How will this help the community? -->

## 🔀 Alternatives considered

<!-- Optional: other solutions you thought about. -->

## 🙋 Contribution

- [ ] I would like to help implement this feature.

---

- [ ] I have searched existing issues and discussions and this is not a duplicate.
