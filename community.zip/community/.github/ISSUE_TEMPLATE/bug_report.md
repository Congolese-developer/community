---
name: "🐛 Bug Report"
about: Report something broken in this repository (broken link, wrong instruction, template error).
title: "[Bug]: "
labels: ["bug", "needs-triage"]
assignees: []
---

<!--
Thank you for helping us improve! 🙏
Before submitting, please search existing issues to make sure this bug has not already been reported.
Bugs in a specific community project should be reported in that project's repository.
Never report security vulnerabilities or Code of Conduct violations in a public issue.
-->

## 🐛 Bug description

<!-- A clear and concise description of what the bug is. -->

## 🔁 Steps to reproduce

1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See the problem

## ✅ Expected behavior

<!-- What did you expect to happen? -->

## ❌ Actual behavior

<!-- What actually happened? Add screenshots if they help. -->

## 💻 Environment

- **Device / OS:** <!-- e.g. Windows 11, Ubuntu 24.04, Android 14 -->
- **Browser (if relevant):** <!-- e.g. Chrome 131, Firefox 133 -->
- **File or page affected:** <!-- e.g. docs/getting-started.md -->

## 📎 Additional context

<!-- Anything else that could help us understand the problem. -->

---

- [ ] I have searched existing issues and this is not a duplicate.
- [ ] I have read the [Code of Conduct](../blob/main/CODE_OF_CONDUCT.md).
