---
name: "🔧 Improvement Suggestion"
about: Suggest an improvement to something that already exists (documentation, process, templates, branding).
title: "[Improvement]: "
labels: ["improvement", "needs-triage"]
assignees: []
---

<!--
Thank you for helping us get better! 🔧
Use this template to improve something that already exists.
For a brand-new feature, use the "Feature Request" template.
-->

## 📍 What should be improved?

<!-- Name the file, page, template or process. Example: docs/faq.md, the Join Community template... -->

## 🤔 Current situation

<!-- What is unclear, missing, slow or difficult today? -->

## 💡 Suggested improvement

<!-- Describe your suggestion as concretely as possible. -->

## 🌟 Why it matters

<!-- Who benefits, and how? -->

## 🙋 Contribution

- [ ] I can open a Pull Request with this improvement.

---

- [ ] I have searched existing issues and discussions and this is not a duplicate.
