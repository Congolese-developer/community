---
name: "🚀 Project Proposal"
about: Propose a new open-source project for the Congolese Developers community.
title: "[Project Proposal]: "
labels: ["project-proposal", "needs-triage"]
assignees: []
---

<!--
Thank you for proposing a project! 🚀
Please check the project directory (docs/projects.md) first to see if a similar project exists.
The community will give feedback for at least 7 days before administrators decide (see GOVERNANCE.md).
-->

## 📛 Project name

<!-- A short, clear name. You can change it later. -->

## 📝 Description

<!-- In 2–4 sentences: what is this project? -->

## 🎯 Problem addressed

<!-- What real problem does it solve? For whom? In the DRC, in Africa, or globally? -->

## 🛠 Proposed technologies

<!-- Languages, frameworks, databases, platforms. Example: Python, FastAPI, PostgreSQL, Flutter -->

## ✅ Main features

<!-- List the most important features of a first version (MVP). -->

- [ ] Feature 1
- [ ] Feature 2
- [ ] Feature 3

## 👥 Potential contributors

<!-- Who could work on it? Mention GitHub usernames of people who agreed, or the skills needed. -->

## 🏁 Project objectives

<!-- What does success look like in 3, 6 and 12 months? -->

## 📄 Proposed license

<!-- Example: MIT, Apache-2.0, GPL-3.0. Choose one at https://choosealicense.com -->

## 🙋 Maintainer

- [ ] I am willing to be the maintainer of this project.

---

- [ ] I have checked the [project directory](../blob/main/docs/projects.md) and this project does not already exist.
- [ ] I have read the [Code of Conduct](../blob/main/CODE_OF_CONDUCT.md).
