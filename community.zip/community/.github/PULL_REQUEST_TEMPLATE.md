<!--
Thank you for your contribution! 🇨🇩
Please fill in this template. New to Pull Requests? Read CONTRIBUTING.md.
The PR title should follow Conventional Commits, e.g. "docs: fix typo in FAQ".
-->

## 📝 Description

<!-- What does this Pull Request change, and why? -->

## 🔗 Related issue

<!-- Link the issue this PR resolves. "Closes #123" closes it automatically when merged. -->

Closes #

## 🏷️ Type of change

- [ ] `feat` — New feature
- [ ] `fix` — Bug fix
- [ ] `docs` — Documentation
- [ ] `refactor` — Restructuring without behavior change
- [ ] `test` — Tests
- [ ] `chore` — Maintenance

## 📸 Screenshots (if relevant)

<!-- For visual changes (README, banners, logo), add before/after screenshots. -->

## ✅ Checklist

- [ ] My PR title and commits follow [Conventional Commits](https://www.conventionalcommits.org/).
- [ ] I have previewed my Markdown changes and checked that links work.
- [ ] My changes are focused on a single topic.
- [ ] I have not added invented contact information, social links or projects.
- [ ] I have read the [Contributing guide](../blob/main/CONTRIBUTING.md) and the [Code of Conduct](../blob/main/CODE_OF_CONDUCT.md).
