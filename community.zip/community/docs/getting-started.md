# Getting Started

Welcome to **Congolese Developers**! 🇨🇩 This guide helps you take your first steps — even
if you have never used Git or GitHub before.

> 🇫🇷 Version française résumée : [docs/fr/README.md](fr/README.md#-premiers-pas).

---

## Table of Contents

- [1. Create a GitHub account](#1-create-a-github-account)
- [2. Join the community](#2-join-the-community)
- [3. Install the essential tools](#3-install-the-essential-tools)
- [4. Learn the basics of Git](#4-learn-the-basics-of-git)
- [5. Make your first contribution](#5-make-your-first-contribution)
- [6. Learning resources](#6-learning-resources)
- [7. Tips for developers in the DRC](#7-tips-for-developers-in-the-drc)

---

## 1. Create a GitHub account

1. Go to [github.com/signup](https://github.com/signup).
2. Choose a professional username — it will appear on all your contributions.
3. Add a profile photo, your name and a short bio. A complete profile builds trust.
4. Enable **two-factor authentication** (Settings → Password and authentication) to protect
   your account.

> 🎓 **Students:** the [GitHub Student Developer Pack](https://education.github.com/pack)
> gives free access to many professional tools.

## 2. Join the community

1. Open a **🙋 Join the Community** issue from [New issue](../../../issues/new/choose).
2. Introduce yourself in the *Introductions* category of [Discussions](../../../discussions).
3. **Star** ⭐ and **Watch** 👀 this repository to receive announcements.

## 3. Install the essential tools

| Tool | Why | Download |
|:--|:--|:--|
| **Git** | Track changes and collaborate | [git-scm.com](https://git-scm.com/downloads) |
| **A code editor** | Write code and documentation | [Visual Studio Code](https://code.visualstudio.com/) (free) |
| **A terminal** | Run Git commands | Built into macOS/Linux; on Windows, *Git Bash* is installed with Git |

After installing Git, configure your identity (use the email of your GitHub account):

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git --version   # check that Git is installed
```

> 💡 **Limited bandwidth?** You can edit Markdown files directly on GitHub in your browser
> (open a file, click the ✏️ pencil icon). GitHub creates the fork and branch for you.

## 4. Learn the basics of Git

The commands you will use most often:

| Command | What it does |
|:--|:--|
| `git clone <url>` | Download a repository to your computer |
| `git status` | Show which files have changed |
| `git checkout -b <branch>` | Create and switch to a new branch |
| `git add <file>` | Prepare a file for the next commit |
| `git commit -m "<message>"` | Save a snapshot of your changes |
| `git push origin <branch>` | Send your branch to GitHub |
| `git pull upstream main` | Get the latest changes from the original repository |

Key vocabulary:

- **Repository (repo)** — a project folder tracked by Git.
- **Fork** — your own copy of someone else's repository on GitHub.
- **Branch** — a separate line of work, so `main` stays clean.
- **Commit** — a saved snapshot of changes, with a message.
- **Pull Request (PR)** — a request to merge your changes into the original repository.
- **Issue** — a ticket to report a bug, suggest an idea or ask for something.

## 5. Make your first contribution

Good first contributions:

- Fix a typo or an unclear sentence in the documentation.
- Add a high-quality free resource to the [learning resources](#6-learning-resources) below.
- Improve a French translation in [docs/fr](fr/README.md).
- Pick an issue labeled [`good first issue`](../../../issues?q=is%3Aissue+is%3Aopen+label%3A%22good+first+issue%22).

Then follow the step-by-step guide in [CONTRIBUTING.md](../CONTRIBUTING.md).

## 6. Learning resources

Free, reputable resources to learn and progress. Contributions to this list are welcome —
please add only free or widely accessible resources.

**Git and open source**

- [GitHub Skills](https://skills.github.com/) — interactive courses inside GitHub
- [Pro Git book](https://git-scm.com/book/en/v2) — the complete Git reference (also in French)
- [First Contributions](https://github.com/firstcontributions/first-contributions) — practice your first PR
- [Open Source Guides](https://opensource.guide/) — how open source works

**Web development**

- [MDN Web Docs](https://developer.mozilla.org/) — HTML, CSS, JavaScript reference (available in French)
- [freeCodeCamp](https://www.freecodecamp.org/) — free full curriculum with certifications
- [The Odin Project](https://www.theodinproject.com/) — full-stack path

**Programming languages**

- [Python official tutorial](https://docs.python.org/3/tutorial/) (available in French)
- [TypeScript handbook](https://www.typescriptlang.org/docs/handbook/intro.html)
- [The Rust book](https://doc.rust-lang.org/book/)
- [A Tour of Go](https://go.dev/tour/)

**Mobile**

- [Flutter documentation](https://docs.flutter.dev/)
- [Android developers (Kotlin)](https://developer.android.com/courses)

**Data and AI**

- [Kaggle Learn](https://www.kaggle.com/learn) — short practical courses
- [fast.ai](https://course.fast.ai/) — practical deep learning
- [Hugging Face courses](https://huggingface.co/learn)

**Computer science foundations**

- [CS50](https://cs50.harvard.edu/x/) — Harvard's free introduction to computer science

## 7. Tips for developers in the DRC

- **Work offline when you can.** Git works fully offline; you only need a connection to
  `push` and `pull`. Commit often locally and push when you have a connection.
- **Save data.** Use `git clone --depth 1 <url>` to download only the latest version of a
  large repository.
- **Ask in French if you need to.** Discussions and issues in French are welcome.
- **Build in public.** Your GitHub profile is your portfolio — contributions to community
  projects are visible to recruiters worldwide.

---

**Next step:** read [CONTRIBUTING.md](../CONTRIBUTING.md) and open your first Pull Request. 🚀
