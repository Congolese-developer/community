# Community Guidelines

These guidelines explain **how we work together day to day**. They complement the
[Code of Conduct](../CODE_OF_CONDUCT.md), which defines the rules of behavior and how they
are enforced.

> 🇫🇷 Résumé en français : [docs/fr/README.md](fr/README.md#-code-de-conduite).

---

## Table of Contents

- [Our spirit](#our-spirit)
- [Where to post what](#where-to-post-what)
- [Asking good questions](#asking-good-questions)
- [Answering and reviewing](#answering-and-reviewing)
- [Languages](#languages)
- [Self-promotion and job offers](#self-promotion-and-job-offers)
- [Privacy and safety](#privacy-and-safety)
- [Respecting licenses and intellectual property](#respecting-licenses-and-intellectual-property)
- [Using the community name and logo](#using-the-community-name-and-logo)

---

## Our spirit

- **One community, 26 provinces and the diaspora.** No region, city or group is more
  important than another.
- **Every technology is welcome.** We don't argue about "the best language" — we help each
  other build.
- **Beginners are the future.** Patience with newcomers is a core responsibility of every
  member.
- **Build in public.** Share your work, your progress and your mistakes; we learn together.

## Where to post what

| You want to… | Go to |
|:--|:--|
| Read official news | Discussions → **Announcements** |
| Chat about anything tech-related | Discussions → **General** |
| Say hello | Discussions → **Introductions** |
| Share or debate an idea | Discussions → **Ideas & Proposals** |
| Ask for help | Discussions → **Help & Support** |
| Show what you built | Discussions → **Projects Showcase** |
| Share a tutorial, course or article | Discussions → **Learning & Resources** |
| Join the community | Issues → **🙋 Join the Community** |
| Report a bug in this repository | Issues → **🐛 Bug Report** |
| Request a feature / improvement | Issues → **✨ Feature Request** / **🔧 Improvement Suggestion** |
| Propose a new project | Issues → **🚀 Project Proposal** |

**Rule of thumb:** *Discussions* are for conversations; *Issues* are for actionable work.

## Asking good questions

A good question gets a faster, better answer:

1. **Search first** — your question may already have an answer.
2. **Use a clear title** — "Django: `ImproperlyConfigured` error when running migrations"
   rather than "Help please!!!"
3. **Explain the context** — what you're trying to do, what you tried, what happened.
4. **Share code as text** in a code block (` ```python `), not as a photo of your screen.
5. **Include the full error message.**
6. **Follow up** — say what worked and mark the answer, so others benefit.

## Answering and reviewing

- Be **kind and specific**. Explain *why*, not just *what*.
- Critique the **code, never the person**.
- Prefer suggestions ("What do you think about…?") over orders.
- Recognize good work — a simple "thank you" matters.
- If you don't have time for a full review, say so rather than leaving someone waiting.

## Languages

- **English** is the primary language of documentation, commit messages and code comments,
  so the community stays accessible internationally.
- **French** is welcome in issues and discussions. If you can, add a short English summary to
  reach more people.
- Other languages spoken in the DRC (Lingala, Swahili, Kikongo, Tshiluba) are welcome in
  informal conversations; please add a French or English translation when the topic concerns
  everyone.

## Self-promotion and job offers

- Sharing **your own open-source projects** is encouraged in *Projects Showcase*.
- **Job and internship offers** are welcome in *General* if they include the company name,
  location (or remote), and a clear way to apply.
- Repeated advertising, paid-course promotion, referral links and unrelated commercial
  content are not allowed.

## Privacy and safety

- Never post **phone numbers, home addresses, ID numbers, passwords, API keys or tokens** in
  issues, discussions or code.
- If you accidentally commit a secret, **revoke it immediately**, then ask a maintainer for
  help cleaning the history.
- Be careful with accounts claiming to represent Congolese Developers: official channels are
  listed only in the [README](../README.md#-contact-and-links).

## Respecting licenses and intellectual property

- Only contribute content you have the right to share.
- Credit sources when you reuse text, images or code.
- Respect the license of every project — this repository uses the [MIT License](../LICENSE).

## Using the community name and logo

- You may use the name and logo to **refer to** the community, or to show that a project is
  an official community project.
- Do not use them to suggest an official endorsement, for commercial products, or to create
  accounts in the community's name without approval from the administrators.

---

Questions about these guidelines? Ask in [Discussions](../../../discussions) or propose a
change with a Pull Request.
