<div align="center">

<img src="../../assets/logo/logo.svg" alt="Logo Congolese Developers" width="100">

# Congolese Developers — Version française

### *Construire la technologie ensemble, de la RD Congo vers le monde.*

[🇬🇧 English version](../../README.md)

</div>

---

Ce document présente la communauté en français. La documentation de référence est rédigée en
**anglais** pour rester accessible à l'international ; en cas de différence, la version
anglaise fait foi. Vous pouvez néanmoins **ouvrir vos issues et discussions en français**.

## Sommaire

- [Présentation](#-présentation)
- [Premiers pas](#-premiers-pas)
- [Contribuer](#-contribuer)
- [Projets](#-projets)
- [Code de conduite](#-code-de-conduite)
- [Gouvernance](#️-gouvernance)
- [Feuille de route](#️-feuille-de-route)
- [Questions fréquentes](#-questions-fréquentes)
- [Aider à traduire](#-aider-à-traduire)

---

## 👋 Présentation

**Congolese Developers** est une communauté technologique open source qui rassemble les
développeurs, ingénieurs, étudiants, chercheurs et passionnés de technologie de la
République démocratique du Congo — au pays comme dans la diaspora.

**Notre mission :** connecter les développeurs congolais, encourager la collaboration, créer
des logiciels open source, partager les connaissances techniques et contribuer à la
technologie mondiale.

**Nos valeurs :** Open source · Collaboration · Innovation · Partage des connaissances ·
Inclusivité · Transparence.

La communauté est **indépendante de toute technologie** : backend, frontend, mobile, données
et intelligence artificielle, DevOps, cloud, cybersécurité, systèmes embarqués, calcul
scientifique, données ouvertes… tous les langages sont les bienvenus.

## 🚀 Premiers pas

1. **Créez un compte GitHub** sur [github.com/signup](https://github.com/signup).
2. **Rejoignez la communauté** en ouvrant une issue **🙋 Join the Community** depuis
   [New issue](../../../../issues/new/choose). Le formulaire est en anglais, mais vous pouvez
   le remplir en français.
3. **Présentez-vous** dans la catégorie *Introductions* des
   [Discussions](../../../../discussions).
4. **Ajoutez une étoile ⭐** au dépôt pour suivre les annonces.

Nouveau avec Git ? Le guide [Getting Started](../getting-started.md) explique l'installation
des outils et les commandes de base. Le livre [Pro Git](https://git-scm.com/book/fr/v2) est
disponible gratuitement en français.

## 🤝 Contribuer

Toute contribution compte : code, documentation, traduction, design, signalement de bugs,
réponses aux questions des autres membres.

```bash
# 1. Forkez le dépôt sur GitHub, puis clonez votre fork
git clone https://github.com/<votre-nom-utilisateur>/community.git
cd community

# 2. Créez une branche
git checkout -b docs/traduction-faq

# 3. Modifiez les fichiers, puis faites un commit conventionnel (en anglais)
git add .
git commit -m "docs: translate FAQ into French"

# 4. Poussez la branche et ouvrez une Pull Request sur GitHub
git push origin docs/traduction-faq
```

**Types de commit** ([Conventional Commits](https://www.conventionalcommits.org/fr/)) :

| Type | Utilisation |
|:--|:--|
| `feat` | Nouvelle fonctionnalité |
| `fix` | Correction de bug |
| `docs` | Documentation |
| `refactor` | Restructuration sans changement de comportement |
| `test` | Ajout ou modification de tests |
| `chore` | Tâches de maintenance |

Le guide complet, étape par étape, se trouve dans [CONTRIBUTING.md](../../CONTRIBUTING.md).

## 🧩 Projets

Il n'existe **pas encore de projet officiel** : c'est l'occasion de lancer le premier !

**Initiatives proposées** (pas encore de dépôt ni de mainteneur) : systèmes de gestion de la
santé, plateformes éducatives, technologies agricoles, technologies financières, technologies
minières, numérisation des services publics, bibliothèques de calcul scientifique,
applications d'intelligence artificielle.

**Proposer un projet :** ouvrez une issue **🚀 Project Proposal**. La communauté donne son
avis pendant au moins 7 jours, puis les administrateurs décident. Le processus complet est
décrit dans [docs/projects.md](../projects.md).

## 📜 Code de conduite

Notre communauté accueille **tout le monde**, quels que soient la province ou le lieu de
résidence, le langage de programmation, le niveau d'expérience, le parcours scolaire ou la
situation professionnelle.

Sont **interdits** : le harcèlement, la discrimination (y compris régionale ou ethnique), les
insultes, l'intimidation et tout comportement irrespectueux, comme se moquer du niveau ou des
questions de quelqu'un.

Les signalements se font **en privé** auprès des administrateurs. Texte complet (basé sur le
Contributor Covenant 2.1) : [CODE_OF_CONDUCT.md](../../CODE_OF_CONDUCT.md). Règles de
fonctionnement au quotidien : [docs/community-guidelines.md](../community-guidelines.md).

## 🏛️ Gouvernance

| Rôle | Responsabilités |
|:--|:--|
| **Fondateur** | Définit la vision, coordonne l'organisation, nomme les premiers mainteneurs |
| **Administrateurs de l'organisation** | Gèrent les paramètres GitHub, les permissions et les dépôts |
| **Mainteneurs de projet** | Gèrent un projet, relisent les Pull Requests, traitent les issues |
| **Contributeurs** | Proposent du code, améliorent la documentation, signalent des bugs |
| **Membres** | Partagent des idées, participent aux discussions, aident les nouveaux |

Les décisions sont prises de manière **transparente**, par consensus, et documentées
publiquement. Détails : [GOVERNANCE.md](../../GOVERNANCE.md).

## 🗺️ Feuille de route

1. **Fondation** — dépôt communautaire, organisation GitHub, Discussions, premiers administrateurs.
2. **Croissance** — premiers membres dans de nombreuses provinces, traductions françaises complètes.
3. **Projets** — premiers projets open source communautaires, hackathon.
4. **Impact** — projets utilisés en RDC, mentorat, groupes locaux, partenariats.

Détails : [docs/roadmap.md](../roadmap.md).

## ❓ Questions fréquentes

**Qui peut rejoindre la communauté ?** Toute personne intéressée par la technologie et la
RDC : développeurs, étudiants, chercheurs, designers, ingénieurs — au pays ou à l'étranger.

**Faut-il être expérimenté ?** Non. Les débutants sont particulièrement les bienvenus.

**Est-ce gratuit ?** Oui, entièrement.

**Puis-je écrire en français ?** Oui, dans les issues et les discussions. La documentation de
référence et les messages de commit restent en anglais.

**Quelle est la différence entre Issues et Discussions ?** Les *Issues* servent au travail
concret (bugs, propositions, adhésion) ; les *Discussions* servent aux échanges (questions,
idées, présentations).

**Comment contacter la communauté ?** Via les [Discussions](../../../../discussions) et les
[Issues](../../../../issues) GitHub. Les réseaux sociaux officiels seront ajoutés au README
dès leur création.

Plus de réponses (en anglais) : [docs/faq.md](../faq.md).

## 🌍 Aider à traduire

Vous souhaitez traduire un document complet en français ? Merci ! 🙏

1. Créez le fichier traduit dans `docs/fr/` en gardant le même nom
   (par exemple `docs/fr/getting-started.md`).
2. Ajoutez un lien vers la traduction dans ce document.
3. Ouvrez une Pull Request intitulée `docs: add French translation of <document>`.

---

<div align="center">

*Fait par les développeurs congolais, pour le monde.* 🇨🇩

</div>
