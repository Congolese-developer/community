# Frequently Asked Questions

> 🇫🇷 Questions fréquentes en français : [docs/fr/README.md](fr/README.md#-questions-fréquentes).

---

## Table of Contents

**About the community**

- [What is Congolese Developers?](#what-is-congolese-developers)
- [Who can join?](#who-can-join)
- [Do I need to live in the DRC?](#do-i-need-to-live-in-the-drc)
- [Is it free?](#is-it-free)
- [Is the community linked to a company, a political party or the government?](#is-the-community-linked-to-a-company-a-political-party-or-the-government)

**Joining and participating**

- [How do I join?](#how-do-i-join)
- [Do I need to be an experienced developer?](#do-i-need-to-be-an-experienced-developer)
- [Which programming languages are accepted?](#which-programming-languages-are-accepted)
- [Can I write in French?](#can-i-write-in-french)
- [What is the difference between Issues and Discussions?](#what-is-the-difference-between-issues-and-discussions)

**Contributing and projects**

- [How can I contribute if I'm a beginner?](#how-can-i-contribute-if-im-a-beginner)
- [How do I propose a project?](#how-do-i-propose-a-project)
- [Who owns the code of community projects?](#who-owns-the-code-of-community-projects)
- [Can I add my personal project to the community?](#can-i-add-my-personal-project-to-the-community)
- [How do I become a maintainer?](#how-do-i-become-a-maintainer)

**Safety and contact**

- [How do I report inappropriate behavior?](#how-do-i-report-inappropriate-behavior)
- [How do I contact the community?](#how-do-i-contact-the-community)

---

## About the community

### What is Congolese Developers?

An open-source technology community that brings together software developers, engineers,
students, researchers and technology enthusiasts from the Democratic Republic of Congo to
collaborate, share knowledge and build open-source software.

### Who can join?

Anyone interested in technology and the DRC: developers, students, researchers, designers,
engineers, data scientists and enthusiasts. Friends of the community from other countries are
welcome too.

### Do I need to live in the DRC?

No. Congolese developers in the diaspora are full members, and so are people elsewhere who
want to contribute to the mission.

### Is it free?

Yes. Membership, documentation and all community resources are free.

### Is the community linked to a company, a political party or the government?

No. Congolese Developers is an independent, volunteer-run open-source community. Political
campaigning is out of scope in community spaces.

## Joining and participating

### How do I join?

Open a **🙋 Join the Community** issue from [New issue](../../../issues/new/choose), then
introduce yourself in the *Introductions* category of [Discussions](../../../discussions).
See the [Getting Started guide](getting-started.md#2-join-the-community).

### Do I need to be an experienced developer?

No. Beginners are especially welcome. Start with the [Getting Started guide](getting-started.md).

### Which programming languages are accepted?

All of them. The community is technology-independent: Python, JavaScript, Java, C#, PHP, Go,
Rust, Dart, Kotlin, Swift and anything else — as well as data, AI, DevOps, cybersecurity,
embedded systems and scientific computing.

### Can I write in French?

Yes. English is the primary language of the documentation so the community stays accessible
internationally, but you can open issues and discussions in French. See
[Languages](community-guidelines.md#languages) and the [French overview](fr/README.md).

### What is the difference between Issues and Discussions?

**Issues** are for actionable work: bugs, feature requests, project proposals and joining.
**Discussions** are for conversations: questions, ideas, introductions, sharing resources.
See [Where to post what](community-guidelines.md#where-to-post-what).

## Contributing and projects

### How can I contribute if I'm a beginner?

Fix a typo, improve a sentence, add a learning resource, translate a page into French, or
answer a question in Discussions. Then follow [CONTRIBUTING.md](../CONTRIBUTING.md) step by
step.

### How do I propose a project?

Open a **🚀 Project Proposal** issue. The full process is in
[docs/projects.md](projects.md#how-a-project-is-created).

### Who owns the code of community projects?

The contributors keep the copyright on their contributions, and the code is shared under the
project's open-source license (MIT for this repository). Anyone can use, study, modify and
share it under the terms of that license.

### Can I add my personal project to the community?

You can **showcase** it in the *Projects Showcase* category of Discussions. To make it an
**official community project** (hosted in the organization), submit a project proposal.

### How do I become a maintainer?

Contribute regularly and constructively; maintainers and administrators can then nominate
you. See [GOVERNANCE.md](../GOVERNANCE.md#becoming-a-maintainer-or-administrator).

## Safety and contact

### How do I report inappropriate behavior?

Report it **privately** to the Organization Administrators, as described in the
[Code of Conduct](../CODE_OF_CONDUCT.md#enforcement). Do not report conduct issues publicly.

### How do I contact the community?

Through [GitHub Discussions](../../../discussions) and [Issues](../../../issues). Official
social media accounts and email will be listed in the
[README](../README.md#-contact-and-links) once they exist.

---

**Your question isn't here?** Ask it in *Help & Support* in [Discussions](../../../discussions),
or open a Pull Request to add it to this FAQ.
