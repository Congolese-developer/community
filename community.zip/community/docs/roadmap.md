# Roadmap

This roadmap describes how we plan to grow Congolese Developers. It is organized in
**phases** rather than fixed dates: we move to the next phase when the goals of the current
one are reached.

Progress is tracked publicly in issues and, when useful, in a GitHub Project board.

> 🇫🇷 Résumé en français : [docs/fr/README.md](fr/README.md#️-feuille-de-route).

---

## Phase 1 — Foundation 🏗️

*Goal: a professional, welcoming home for the community.*

- [x] Define the vision, mission and core values
- [x] Publish the community repository: README, contributing guide, code of conduct, governance
- [x] Create issue templates (join, bug, feature, improvement, project proposal) and a PR template
- [x] Write beginner documentation and a French overview
- [ ] Create the GitHub organization and publish this repository
- [ ] Enable and configure GitHub Discussions with the community categories
- [ ] Appoint at least two Organization Administrators
- [ ] Replace the placeholder logo with the final official logo, if different

## Phase 2 — Growth 🌱

*Goal: members from many provinces, active discussions.*

- [ ] Welcome the first 100 members through *Join the Community* issues
- [ ] Have members from at least 10 provinces and the diaspora
- [ ] Translate the main documents (Contributing, Code of Conduct, Getting Started) fully into French
- [ ] Publish a curated list of learning resources contributed by members
- [ ] Create official social media accounts and list them in the README
- [ ] Organize the first online community meetup

## Phase 3 — Projects 🚀

*Goal: the first community-built open-source software.*

- [ ] Approve the first community projects from proposals
- [ ] Reach the `Active` status for at least three projects
- [ ] Appoint maintainers for each project
- [ ] Set up shared continuous integration templates for community projects
- [ ] Run a community hackathon around one of the [proposed initiatives](projects.md#proposed-initiatives)

## Phase 4 — Impact 🌍

*Goal: recognized national and international contributions.*

- [ ] Community projects used by real organizations in the DRC
- [ ] Mentorship program pairing experienced developers with beginners
- [ ] Local chapters or study groups in major cities (Kinshasa, Lubumbashi, Goma, Kisangani…)
- [ ] Partnerships with universities and tech hubs
- [ ] Members contributing to major international open-source projects

---

## Suggesting changes to the roadmap

The roadmap belongs to the community. To suggest a change:

- Start a conversation in *Ideas & Proposals* in [Discussions](../../../discussions), or
- Open an **🔧 Improvement Suggestion** issue from [New issue](../../../issues/new/choose).

Roadmap changes are reviewed like other community-wide documents (see
[GOVERNANCE.md](../GOVERNANCE.md#decision-making)).
