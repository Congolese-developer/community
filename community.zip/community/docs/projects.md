# Community Projects

This is the **project directory** of Congolese Developers: the official list of community
projects and the process for creating new ones.

> 🇫🇷 Résumé en français : [docs/fr/README.md](fr/README.md#-projets).

---

## Table of Contents

- [Project status levels](#project-status-levels)
- [Official projects](#official-projects)
- [Proposed initiatives](#proposed-initiatives)
- [How a project is created](#how-a-project-is-created)
- [Requirements for official projects](#requirements-for-official-projects)
- [How to list a project](#how-to-list-a-project)
- [Project entry template](#project-entry-template)

---

## Project status levels

| Status | Meaning |
|:--|:--|
| 🟣 `Proposed` | An idea or proposal under community discussion. No repository yet. |
| 🔵 `Incubating` | Approved; a repository exists and the first version is being built. |
| 🟢 `Active` | Usable, maintained, and accepting contributions. |
| 🟡 `Seeking maintainers` | Useful but needs new maintainers to continue. |
| ⚪ `Archived` | No longer maintained; kept read-only for reference. |

---

## Official projects

> **There are no official community projects yet.** The first projects will be listed here
> as soon as they are approved and their repository is created.
>
> Want to be the first? [Propose a project](#how-a-project-is-created).

| Project | Description | Repository | Maintainer | Language | License | Status |
|:--|:--|:--|:--|:--|:--|:--:|
| *—* | *No project yet* | *—* | *—* | *—* | *—* | *—* |

---

## Proposed initiatives

These are **areas of high impact for the DRC** identified as priorities. They are **not
existing projects**: they have no repository and no maintainer yet. Each one is waiting for
someone to turn it into a concrete [project proposal](#how-a-project-is-created).

| Initiative | Example ideas | Status |
|:--|:--|:--:|
| 🏥 **Healthcare management systems** | Patient records for clinics, pharmacy stock management, appointment scheduling | `Proposed` |
| 🎓 **Educational platforms** | Offline-first learning apps, school management, exam preparation | `Proposed` |
| 🌾 **Agricultural technology** | Market price information, crop advice, farm cooperatives management | `Proposed` |
| 💳 **Financial technology** | Mobile money integration libraries, budgeting tools, microfinance management | `Proposed` |
| ⛏️ **Mining technology** | Traceability tools, geological data processing, safety monitoring | `Proposed` |
| 🏛️ **Public services digitization** | Open data portals, administrative procedure guides, civic tech | `Proposed` |
| 🔬 **Scientific computing libraries** | Open libraries for engineering, physics, metallurgy and environmental science | `Proposed` |
| 🤖 **Artificial intelligence applications** | Language models and datasets for Lingala, Swahili, Kikongo and Tshiluba; computer vision | `Proposed` |

> The "Example ideas" column is illustrative only — feel free to propose something entirely
> different.

---

## How a project is created

```text
 💡 Idea  ──▶  🚀 Proposal  ──▶  🗳️ Review  ──▶  🔵 Incubating  ──▶  🟢 Active
(Discussions)   (Issue)         (≥ 7 days)      (new repo)         (v1 released)
```

1. **Discuss (optional).** Share the idea in *Ideas & Proposals* in
   [Discussions](../../../discussions) to gather early feedback.
2. **Propose.** Open a **🚀 Project Proposal** issue from [New issue](../../../issues/new/choose).
   Describe the problem, technologies, main features, objectives and potential contributors.
3. **Review.** The community comments for at least **7 days**. Administrators then decide,
   following [GOVERNANCE.md](../GOVERNANCE.md#decision-making), and explain their decision.
4. **Incubate.** If approved, an administrator creates a repository in the organization and
   gives the proposer maintainer rights. The project is added to
   [Official projects](#official-projects) with the `Incubating` status.
5. **Activate.** When the project has a usable first version and meets the
   [requirements](#requirements-for-official-projects), its status becomes `Active`.

---

## Requirements for official projects

Every official project repository must have:

- [ ] A clear `README.md` (what it is, how to install, how to use, how to contribute)
- [ ] An open-source `LICENSE` approved by the [OSI](https://opensource.org/licenses)
- [ ] A `CONTRIBUTING.md` (it may link to this repository's [guide](../CONTRIBUTING.md))
- [ ] A link to the community [Code of Conduct](../CODE_OF_CONDUCT.md)
- [ ] At least **one active maintainer**, ideally two
- [ ] Issues enabled, with a few labeled `good first issue` when possible
- [ ] No secrets, passwords or personal data in the code or history

---

## How to list a project

Only **real, existing** projects are listed. To add or update a project:

1. Fork this repository and edit `docs/projects.md`.
2. Add a row to the [Official projects](#official-projects) table using the
   [template](#project-entry-template) below.
3. Open a Pull Request with the title `docs: add <project-name> to project directory`.

Maintainers are responsible for keeping their project's status up to date.

---

## Project entry template

Use this row in the [Official projects](#official-projects) table:

```markdown
| [Project Name](https://github.com/ORG/project-repo) | One-sentence description | [ORG/project-repo](https://github.com/ORG/project-repo) | [@maintainer](https://github.com/maintainer) | Python | MIT | `Incubating` |
```

Each project's own README should also contain a **How to contribute** section with:

- how to set up the development environment,
- how to run the tests,
- where to find `good first issue` tasks,
- who to contact for help.
