# GitHub Setup Guide (for administrators)

Some features **cannot be activated by files in a repository** — they must be configured by
hand in GitHub's settings. This guide lists every manual step needed to publish and configure
the community repository.

> Audience: the Founder and Organization Administrators.

---

## Table of Contents

- [1. Create the organization](#1-create-the-organization)
- [2. Replace placeholders](#2-replace-placeholders)
- [3. Publish the repository](#3-publish-the-repository)
- [4. Repository settings](#4-repository-settings)
- [5. Enable and configure Discussions](#5-enable-and-configure-discussions)
- [6. Create labels](#6-create-labels)
- [7. Add repository topics](#7-add-repository-topics)
- [8. Protect the main branch](#8-protect-the-main-branch)
- [9. Organization profile and security](#9-organization-profile-and-security)
- [10. GitHub Projects (optional)](#10-github-projects-optional)
- [11. Final checklist](#11-final-checklist)

---

## 1. Create the organization

1. Sign in to GitHub and go to [github.com/organizations/plan](https://github.com/organizations/plan).
2. Choose the **Free** plan.
3. Choose the organization name (for example the name you want in URLs:
   `https://github.com/<organization-name>`). Check that it is available.
4. Add at least **one other trusted owner** as soon as possible (see
   [GOVERNANCE.md](../GOVERNANCE.md#summary-of-permissions)).

## 2. Replace placeholders

Before publishing, replace the placeholders that depend on the real organization name:

| File | Placeholder | Replace with |
|:--|:--|:--|
| `.github/ISSUE_TEMPLATE/config.yml` | `YOUR-ORG` | Your organization name |
| `GOVERNANCE.md` → *Current role holders* | *To be completed* | Real GitHub usernames |
| `assets/logo/logo.svg` | Placeholder logo | The official logo, if you have a different one (keep the same file name) |

Quick replacement on Linux/macOS/Git Bash (run from the repository root):

```bash
sed -i 's/YOUR-ORG/<organization-name>/g' .github/ISSUE_TEMPLATE/config.yml
grep -rn "YOUR-ORG" .   # should print nothing
```

> On macOS, use `sed -i '' 's/YOUR-ORG/<organization-name>/g' ...`.

## 3. Publish the repository

1. In the organization, click **New repository**.
2. Name it **`community`**, set it to **Public**, and **do not** add a README, license or
   `.gitignore` (they already exist here).
3. From this folder, run:

```bash
git init
git add .
git commit -m "feat: initial community repository"
git branch -M main
git remote add origin https://github.com/<organization-name>/community.git
git push -u origin main
```

## 4. Repository settings

Go to **Settings → General** of the `community` repository:

- **Description:** `Official community hub of Congolese Developers — Building Technology Together, From DR Congo to the World. 🇨🇩`
- **Features:** ✅ Issues · ✅ Discussions · ✅ Projects · ❌ Wiki (documentation lives in `docs/`)
- **Pull Requests:** ✅ Allow squash merging · ✅ Automatically delete head branches
- **Social preview:** upload a PNG export of `assets/banners/banner.svg`
  (recommended size 1280 × 640; GitHub does not accept SVG here).

## 5. Enable and configure Discussions

1. **Settings → General → Features → ✅ Discussions**, then open the **Discussions** tab.
2. Click the ✏️ next to **Categories** and create or rename categories as follows:

| # | Category | Format | Description |
|:--:|:--|:--|:--|
| 1 | 📣 Announcements | Announcement | Official news from the administrators |
| 2 | 💬 General | Open-ended discussion | Anything tech-related |
| 3 | 👋 Introductions | Open-ended discussion | Introduce yourself to the community |
| 4 | 💡 Ideas & Proposals | Open-ended discussion | Share and debate ideas before formal proposals |
| 5 | 🙏 Help & Support | Question / Answer | Ask for help; mark the best answer |
| 6 | 🎉 Projects Showcase | Show and tell | Show what you have built |
| 7 | 📚 Learning & Resources | Open-ended discussion | Tutorials, courses, articles, books |

3. Check that the category URLs match the links in `.github/ISSUE_TEMPLATE/config.yml`
   (`help-support`, `introductions`, `ideas-proposals`). Open each category and compare the
   end of the URL; update `config.yml` if GitHub generated a different slug.
4. Publish a welcome post in *Announcements* and **pin** it.

## 6. Create labels

The issue templates apply these labels automatically, but **only if they exist**. Create them
in **Issues → Labels → New label**:

| Label | Color | Description |
|:--|:--|:--|
| `bug` | `#CE1021` | Something is broken |
| `enhancement` | `#0B3D91` | New feature request |
| `improvement` | `#3B6FD8` | Improvement to something existing |
| `project-proposal` | `#F7D618` | Proposal for a new community project |
| `new-member` | `#2EA44F` | Join the community request |
| `needs-triage` | `#D4C5F9` | Waiting for a maintainer to review |
| `good first issue` | `#7057FF` | Good for newcomers |
| `help wanted` | `#008672` | Extra attention is needed |
| `documentation` | `#0075CA` | Improvements or additions to documentation |
| `translation` | `#FBCA04` | French or other language translation |

With the [GitHub CLI](https://cli.github.com/), you can create them in one go:

```bash
R=<organization-name>/community
gh label create bug              --repo $R --color CE1021 --description "Something is broken" --force
gh label create enhancement      --repo $R --color 0B3D91 --description "New feature request" --force
gh label create improvement      --repo $R --color 3B6FD8 --description "Improvement to something existing" --force
gh label create project-proposal --repo $R --color F7D618 --description "Proposal for a new community project" --force
gh label create new-member       --repo $R --color 2EA44F --description "Join the community request" --force
gh label create needs-triage     --repo $R --color D4C5F9 --description "Waiting for a maintainer to review" --force
gh label create "good first issue" --repo $R --color 7057FF --description "Good for newcomers" --force
gh label create "help wanted"    --repo $R --color 008672 --description "Extra attention is needed" --force
gh label create documentation    --repo $R --color 0075CA --description "Improvements or additions to documentation" --force
gh label create translation      --repo $R --color FBCA04 --description "French or other language translation" --force
```

## 7. Add repository topics

On the repository home page, click ⚙️ next to **About** and add topics such as:

```text
community  open-source  drc  congo  dr-congo  africa  developers  kinshasa
lubumbashi  african-developers  hacktoberfest  beginner-friendly
```

## 8. Protect the main branch

**Settings → Rules → Rulesets → New branch ruleset** (or **Settings → Branches**):

- Target: `main`
- ✅ Require a pull request before merging (1 approval)
- ✅ Block force pushes
- ✅ Restrict deletions

## 9. Organization profile and security

In the **organization** settings:

- **Profile:** add the logo, the description, and — once they exist — the official website,
  email and social accounts.
- **Organization profile README (optional):** create a public repository named `.github` in
  the organization with a `profile/README.md` file; it is displayed on the organization's
  home page. You can adapt the top of this repository's README for it.
- **Authentication security:** ✅ Require two-factor authentication for all members.
- **Member privileges:** set *Base permissions* to **Read**, and disable repository creation
  by members if you prefer administrators to create project repositories.
- **Default community health files:** files in the organization's `.github` repository
  (Code of Conduct, Contributing, templates) apply to every repository that does not have its
  own. Copy them there if you want all projects to share them.

## 10. GitHub Projects (optional)

Create an organization-level **Project** (Projects tab → New project → *Board*) to track the
[roadmap](roadmap.md) and project proposals, with columns such as *Proposed*, *In review*,
*Approved*, *Incubating* and *Active*.

## 11. Final checklist

- [ ] Organization created with at least two owners
- [ ] `YOUR-ORG` replaced in `config.yml`
- [ ] Repository `community` published and public
- [ ] Description, topics and social preview set
- [ ] Discussions enabled with the seven categories
- [ ] Labels created
- [ ] `main` branch protected
- [ ] Two-factor authentication required
- [ ] Role holders listed in [GOVERNANCE.md](../GOVERNANCE.md#current-role-holders)
- [ ] Welcome announcement published and pinned
- [ ] New-issue page shows the five templates and the contact links
